from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render

from .models import Login, Signup1, Comic


# Create your views here.
def base(request):
    return render(request, 'loginpage/base.html')


def register(request):
    return render(request, 'loginpage/regiister.html')


def addregister(request):
    if request.method == 'POST':
        name = request.POST['name']
        psw = request.POST['psw']
        new_id = Signup1(name=name, psw=psw)
        new_id.save()
        return render(request,"loginpage/home.html")

    else:
        return render(request,"loginpage/error.html");

def login(request):
    return render(request, 'loginpage/login.html')


def home(request):
    return render(request, 'loginpage/home.html')


def home2(request):
    return render(request, 'loginpage/home2.html')


def checklogin(request):
    uname = request.POST["uname"]
    pwd = request.POST["pwd"]
    flag = Signup1.objects.filter(Q(name=uname) & Q(psw=pwd))
    print(flag)
    if flag and uname=="kc":
        return render(request,"bookspage/kc.html")
    if flag:
        return render(request, "loginpage/home2.html")
    else:
        return render(request, "loginpage/error.html")


def checkbook(request):
    name = request.GET["name"]
    flag = Comic.objects.filter(Q(name=name))
    print(flag)

    if flag:
        if name == "comic":
            return render(request, "bookspage/comic.html")
        elif name == "adventure":
            return render(request, "bookspage/adventure.html")
        elif name == 'demon slayer vol1':
            return render(request, 'bookspage/vol1.html')
        elif name == 'demon slayer vol2':
            return render(request, 'bookspage/vol2.html')
        elif name == 'demon slayer vol3':
            return render(request, 'bookspage/vol3.html')
        elif name == 'demon slayer vol4':
            return render(request, 'bookspage/vol4.html')
        elif name == 'demon slayer vol5':
            return render(request, 'bookspage/vol5.html')
        elif name == 'demon slayer vol6':
            return render(request, 'bookspage/vol6.html')
        elif name == 'demon slayer vol7':
            return render(request, 'bookspage/vol7.html')
        elif name == 'demon slayer vol8':
            return render(request, 'bookspage/vol8.html')
        elif name == 'demon slayer vol9':
            return render(request, 'bookspage/vol9.html')
        elif name == 'demon slayer vol10':
            return render(request, 'bookspage/vol10.html')

    else:
        return render(request, "loginpage/error.html")
