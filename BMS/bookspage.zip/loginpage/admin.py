from django.contrib import admin
from .models import Login, Signup1, Comic

# Register your models here.
admin.site.register(Login)
admin.site.register(Signup1)
admin.site.register(Comic)