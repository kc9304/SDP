from django.shortcuts import render


def main(request):
    return render(request, 'bookspage/main.html')


def one(request):
    return render(request, 'bookspage/comic.html')


def two(request):
    return render(request, 'bookspage/adventure.html')


def vol1(request):
    return render(request, 'bookspage/vol1.html')


def vol2(request):
    return render(request, 'bookspage/vol2.html')


def vol3(request):
    return render(request, 'bookspage/vol3.html')


def vol4(request):
    return render(request, 'bookspage/vol4.html')


def vol5(request):
    return render(request, 'bookspage/vol5.html')


def vol6(request):
    return render(request, 'bookspage/vol6.html')


def vol7(request):
    return render(request, 'bookspage/vol7.html')


def vol8(request):
    return render(request, 'bookspage/vol8.html')


def vol9(request):
    return render(request, 'bookspage/vol9.html')


def vol10(request):
    return render(request, 'bookspage/vol10.html')


def vol2(request):
    return render(request, 'bookspage/vol2.html')
