from django.apps import AppConfig


class BookspageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookspage'
